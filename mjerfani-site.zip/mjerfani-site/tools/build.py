#!/usr/bin/env python3
"""Generate static HTML, JSON-LD, sitemap, robots and contact card. No dependencies.
Edit site.json for shared details; edit the functions below for page copy.
Upload the generated HTML and assets to GitHub Pages; no server runtime is needed.
"""
from pathlib import Path
from html import escape
from urllib.parse import urlparse
import json
import re

ROOT=Path(__file__).resolve().parents[1]
C=json.loads((ROOT/'site.json').read_text(encoding='utf-8'))
BASE=C['url'].rstrip('/')
assert urlparse(BASE).scheme=='https' and urlparse(BASE).hostname
assert urlparse(BASE).path in ('','/'), 'Use the root of your custom domain'
assert re.fullmatch(r'09\d{9}',C['phone'])
assert re.fullmatch(r'\+989\d{9}',C['internationalPhone'])
assert re.fullmatch(r'[A-Za-z0-9]{22}',C['spotifyArtistId'])
for url in C['social'].values(): assert urlparse(url).scheme=='https' and urlparse(url).hostname
E=lambda value:escape(str(value),quote=True)
S=C['social']
ICONS={
'arrow':'<path d="M18 6 6 18M18 18H6V6"/>',
'external':'<path d="M7 17 17 7M7 7h10v10"/>',
'down':'<path d="M12 4v16m-6-6 6 6 6-6"/>',
'chevron':'<path d="m14 6-6 6 6 6"/>',
'menu':'<path d="M4 7h16M4 12h16M4 17h16"/>',
'phone':'<path d="M7.6 3H4.5A1.5 1.5 0 0 0 3 4.7c.8 8.6 7.7 15.5 16.3 16.3a1.5 1.5 0 0 0 1.7-1.5v-3.1l-4.7-1.9-1.8 2.1a15 15 0 0 1-7.1-7.1l2.1-1.8L7.6 3Z"/>',
'copy':'<rect x="8" y="8" width="12" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h3"/>',
'download':'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
'telegram':'<path d="m21 3-4 18-6-5-4 3 1-6 10-7-12 5-4-2L21 3Z"/><path d="m8 13 3 3"/>',
'youtube':'<rect x="2" y="5" width="20" height="14" rx="4"/><path d="m10 9 5 3-5 3Z" fill="currentColor" stroke="none"/>',
'instagram':'<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/>',
'spotify':'<circle cx="12" cy="12" r="10"/><path d="M6 9c4-2 8-1.5 12 .5M7 12.5c3.3-1.5 6.5-1 10 .6M8 16c2.6-1 5-1 8 .4"/>',
'google':'<path d="M20 7a9 9 0 1 0 1 7h-9v-3h10"/>',
'play':'<path d="m9 5 11 7-11 7Z" fill="currentColor" stroke="none"/>',
'star':'<path d="M12 2v20M2 12h20M5 5l14 14M5 19 19 5"/>'}

def icon(name,extra=''):
 return f'<svg class="icon {E(extra)}" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">{ICONS[name]}</svg>'
def ext(key,label,cls='button button-outline',ico=None):
 return f'<a class="{E(cls)}" href="{E(S[key])}" target="_blank" rel="noopener noreferrer">{icon(ico or key)}<span>{label}</span></a>'
def rel(path,current):return ('../' if current else './')+path
def portrait(current,eager=False):
 p=rel('assets/images/',current)
 return f'<img src="{p}mohammad-javad-erfani-800.webp" srcset="{p}mohammad-javad-erfani-480.webp 480w, {p}mohammad-javad-erfani-800.webp 800w, {p}mohammad-javad-erfani-1280.webp 1280w" sizes="(max-width:640px) calc(100vw - 54px), (max-width:1100px) 45vw, 580px" width="1536" height="1536" alt="پرترهٔ محمدجواد عرفانی با کت مشکی و عینک" {"fetchpriority=high" if eager else "loading=lazy"} decoding="async">'
def artwork(current):
 p=rel('assets/images/',current)
 return f'<figure class="music-art"><img src="{p}erfani-artwork-960.webp" srcset="{p}erfani-artwork-480.webp 480w, {p}erfani-artwork-960.webp 960w" sizes="(max-width:640px) calc(100vw - 40px), 520px" width="1536" height="1536" alt="نشان هنری Erfani با نوشتهٔ قرمز روی زمینهٔ مشکی" loading="lazy" decoding="async"><figcaption class="art-caption"><span>نشان هنری عرفانی</span><span class="en-label">ERFANI / VISUAL IDENTITY</span></figcaption></figure>'
def embed():
 return f'<div class="embed-shell"><div class="embed-placeholder"><p>موسیقی را همین‌جا بشنوید.</p><button hidden class="button button-outline" data-spotify-load="{E(C["spotifyArtistId"])}">{icon("play")} بارگذاری پخش‌کننده</button><noscript><a href="{E(S["spotify"])}">رفتن به اسپاتیفای</a></noscript></div></div><p class="embed-note">پخش‌کننده با انتخاب شما از اسپاتیفای بارگذاری می‌شود. <a class="inline-link" href="{E(S["spotify"])}" target="_blank" rel="noopener noreferrer">باز کردن مستقیم اسپاتیفای</a></p>'

SOCIAL_COPY=[('instagram','Instagram','تصویرها و روایت‌های روزمره','@'+C['handle']),('youtube','YouTube','ویدئوها و محتوای منتشرشده','@'+C['handle']),('spotify','Spotify','صفحهٔ هنرمند و آثار موسیقی','ARTIST PROFILE'),('telegram','Telegram','پیام، ارتباط و همراهی','@'+C['handle']),('google','Google','نمایهٔ دانش در گوگل','KNOWLEDGE PANEL')]
NAV=[('','خانه'),('about/','درباره من'),('music/','موسیقی'),('education/','عربی و قرآن'),('contact/','ارتباط')]
def social_grid():
 return '<div class="social-grid">'+''.join(f'<a class="social-card" href="{E(S[k])}" target="_blank" rel="noopener noreferrer"><div class="social-card-top">{icon(k)}{icon("external","out")}</div><strong lang="en">{name}</strong><p>{label}</p><bdi class="handle">{E(handle)}</bdi></a>' for k,name,label,handle in SOCIAL_COPY)+'</div>'
def connections():
 return f'<section class="section connections" id="links" aria-labelledby="links-title"><div class="container"><div class="section-heading"><div class="heading-stack"><p class="eyebrow">۰۴ / در ارتباط</p><h2 id="links-title">یک نام، همه‌جا.</h2></div><p>صفحات رسمی محمدجواد عرفانی؛ برای شنیدن، دیدن و دنبال‌کردن تازه‌ترین فعالیت‌ها.</p></div>{social_grid()}</div></section>'
def brand(current):
 return f'<a class="brand" href="{rel("",current)}" aria-label="محمدجواد عرفانی؛ صفحهٔ اصلی"><span class="brand-mark" lang="en">ERFANI</span><span class="brand-copy"><strong>محمدجواد عرفانی</strong><span lang="en">OFFICIAL WEBSITE</span></span></a>'
def header(current):
 links=''.join(f'<a href="{rel(p,current)}" {"aria-current=page" if p==current else ""}>{l}</a>' for p,l in NAV)
 return f'<a class="skip-link" href="#main">رفتن به محتوای اصلی</a><header class="site-header" id="top"><div class="container nav-inner">{brand(current)}<nav class="primary-nav" id="primary-nav" aria-label="فهرست اصلی">{links}</nav><a class="header-contact" href="tel:{E(C["internationalPhone"])}">در تماس باشیم {icon("arrow")}</a><button class="menu-toggle" aria-label="باز کردن فهرست" aria-expanded="false" aria-controls="primary-nav">{icon("menu")}</button></div></header>'
def band():
 return f'<section class="contact-band" id="contact" aria-labelledby="contact-title"><div class="container contact-band-inner"><div><h2 id="contact-title">هر ارتباط، یک آغاز.</h2><p>برای همکاری هنری، آموزشی و رسانه‌ای در تماس باشیم.</p></div><div class="actions"><a class="button button-light" href="tel:{E(C["internationalPhone"])}">{icon("phone")}<bdi>{E(C["phone"])}</bdi></a>{ext("telegram","پیام در تلگرام")}</div></div></section>'
def footer(current):
 links=''.join(f'<a href="{rel(p,current)}">{l}</a>' for p,l in NAV[1:])
 return f'<footer class="site-footer"><div class="container"><div class="footer-top">{brand(current)}<p>صدا، دانش و ارتباط؛ سه دریچه به دنیای محمدجواد عرفانی.</p><nav class="footer-links" aria-label="پیوندهای پایین صفحه">{links}</nav></div><div class="footer-bottom"><span>© ۲۰۲۶ محمدجواد عرفانی. حقوق محتوا و تصاویر محفوظ است.</span><a href="#top">بازگشت به بالا ↑</a><span class="en-label">MOHAMMAD JAVAD ERFANI</span></div></div></footer>'
def breadcrumbs(label):
 return f'<nav class="container breadcrumb" aria-label="مسیر صفحه"><a href="../">خانه</a>{icon("chevron")}<span aria-current="page">{label}</span></nav>'
def intro(label,title,lead):
 return f'{breadcrumbs(label)}<section class="page-hero"><div class="container"><p class="eyebrow">{label} / محمدجواد عرفانی</p><h1>{title}</h1><p class="lead">{lead}</p></div></section>'
def faq(items):
 return '<div class="faq-list">'+''.join(f'<details><summary>{q}</summary><p>{a}</p></details>' for q,a in items)+'</div>'

def home():
 small=''.join(f'<a href="{E(S[k])}" aria-label="{l} محمدجواد عرفانی" target="_blank" rel="noopener noreferrer">{icon(k)}</a>' for k,l in [('instagram','اینستاگرام'),('youtube','یوتیوب'),('telegram','تلگرام'),('spotify','اسپاتیفای')])
 rows=[('01','خوانندگی','صدا و موسیقی؛ آثار را در صفحهٔ هنرمند دنبال کنید.','music/'),('02','آموزش','عربی و قرآن؛ مسیری برای پرسش، یادگیری و گفت‌وگو.','education/'),('03','پژوهش','توجه به پرسش، بررسی و انتقال روشن مفاهیم.','about/#research'),('04','رسانه','استراتژی محتوا و مدیریت رسانه‌های اجتماعی.','about/#media')]
 activity=''.join(f'<a class="activity-row" href="{link}"><span>{n}</span><h3>{t}</h3><p>{d}</p>{icon("arrow")}</a>' for n,t,d,link in rows)
 return f'''
<section class="hero" aria-labelledby="hero-title"><div class="container"><div class="hero-grid"><div class="hero-copy"><p class="eyebrow">وب‌سایت رسمی <span class="en-label">/ MJERFANI</span></p><h1 id="hero-title">محمدجواد <span>عرفانی</span></h1><p class="hero-latin" lang="en">MOHAMMAD JAVAD ERFANI</p><p class="hero-lead"><strong>خواننده، دبیر و پژوهشگر.</strong><br>در پیوند میان صدا، دانش و ارتباط؛<br>از دنیای موسیقی تا آموزش و رسانه.</p><div class="actions">{ext('spotify','شنیدن در اسپاتیفای','button button-primary')}<a class="button button-outline" href="about/">بیشتر درباره من {icon('arrow')}</a></div><div class="hero-social"><span>همراه من باشید</span>{small}</div></div><figure class="hero-visual"><div class="portrait-wrap">{portrait('',True)}</div><figcaption class="portrait-caption"><div><strong>از صدا تا معنا.</strong><span lang="en">VOICE. KNOWLEDGE. CONNECTION.</span></div>{icon('star')}</figcaption><span class="visual-side" aria-hidden="true">THE OFFICIAL PORTRAIT / MJERFANI</span></figure></div><div class="hero-bottom"><div class="disciplines"><span>موسیقی</span><span class="dot-separator">/</span><span>آموزش</span><span class="dot-separator">/</span><span>پژوهش</span><span class="dot-separator">/</span><span>رسانه</span></div><a href="#about">کمی بیشتر آشنا شویم {icon('down')}</a><span class="en-label">01 — INTRODUCTION</span></div></div></section>
<section class="section paper" id="about" aria-labelledby="about-title"><div class="container"><div class="intro-grid"><div class="heading-stack"><p class="eyebrow">۰۲ / دنیای من</p><h2 id="about-title">یک نام،<br>چند مسیر.</h2></div><div class="intro-body"><p>من محمدجواد عرفانی هستم؛ در موسیقی، تدریس، پژوهش و مدیریت رسانه‌های اجتماعی فعالیت می‌کنم. نقطهٔ اتصال این مسیرها برای من، شیوهٔ انتقال معنا و ارتباط با مخاطب است.</p><p>اینجا می‌توانید با حوزه‌های فعالیت من آشنا شوید، به آثار موسیقی دسترسی داشته باشید و برای گفت‌وگو دربارهٔ عربی و قرآن یا همکاری در سبزوار، مستقیم با من در ارتباط باشید.</p><a class="text-link" href="about/">دربارهٔ محمدجواد عرفانی {icon('arrow')}</a></div></div><div class="activity-list" id="activities">{activity}</div></div></section>
<section class="section" aria-labelledby="music-title"><div class="container music-grid">{artwork('')}<div class="music-copy"><p class="eyebrow">۰۳ / موسیقی</p><h2 id="music-title">گاهی،<br>صدا حرف می‌زند.</h2><p>برای شنیدن آثار محمدجواد عرفانی، به صفحهٔ رسمی هنرمند در اسپاتیفای بروید. ویدئوها و محتوای تصویری را هم می‌توانید در کانال یوتیوب دنبال کنید.</p><div class="actions">{ext('spotify','باز کردن اسپاتیفای','button button-primary')}<a class="text-link" href="music/">دنیای موسیقی {icon('arrow')}</a></div><div class="music-meta"><bdi>Mohammad Javad Erfani</bdi><span>صفحهٔ رسمی هنرمند</span>{icon('spotify','spotify-icon')}</div></div></div></section>
{connections()}<section class="section" aria-labelledby="home-faq"><div class="container content-grid"><div class="heading-stack"><p class="eyebrow">پرسش‌های کوتاه</p><h2 id="home-faq">راهی روشن<br>برای ارتباط.</h2></div>{faq([('چطور با محمدجواد عرفانی تماس بگیرم؟',f'از شمارهٔ <a class="inline-link" href="tel:{C["internationalPhone"]}"><bdi>{C["phone"]}</bdi></a> یا تلگرام <bdi>@{C["handle"]}</bdi> استفاده کنید. برای هماهنگی، موضوع پیام را از ابتدا بنویسید.'),('آثار موسیقی و ویدئوها کجا منتشر می‌شوند؟','پیوند صفحهٔ هنرمند در اسپاتیفای و کانال یوتیوب در بخش صفحات رسمی قرار دارد. هر دو از همین وب‌سایت در دسترس هستند.'),('برای موضوع عربی و قرآن یا هماهنگی در سبزوار از کجا شروع کنم؟','در صفحهٔ <a class="inline-link" href="education/">عربی و قرآن</a>، راهنمای ارسال پرسش و هماهنگی قرار دارد. موضوع، مقطع و شیوهٔ ارتباط موردنظرتان را در پیام مشخص کنید.')])}</div></section>'''

def about():
 return f'''{breadcrumbs('درباره من')}<section class="page-hero"><div class="container about-grid"><div><p class="eyebrow">درباره من / یک معرفی نزدیک‌تر</p><h1>محمدجواد عرفانی</h1><p class="lead">خواننده، دبیر، پژوهشگر و استراتژیست رسانه‌های اجتماعی؛ چهار مسیر با یک نقطهٔ مشترک: ارتباط و انتقال معنا.</p><dl class="profile-table"><div><dt>نام</dt><dd>{E(C['name'])}</dd></div><div><dt>صورت دیگر نام</dt><dd>محمدجواد عرفانی اصل</dd></div><div><dt>نام لاتین</dt><dd><bdi>{E(C['latinName'])}</bdi></dd></div><div><dt>شناسهٔ رسمی</dt><dd><bdi>@{E(C['handle'])}</bdi></dd></div></dl><div class="actions"><a class="button button-primary" href="../contact/">راه‌های ارتباط {icon('arrow')}</a>{ext('google','نمایهٔ گوگل','text-link','external')}</div></div><figure class="about-portrait">{portrait('about/',True)}</figure></div></section>
<section class="section paper"><div class="container content-grid"><div class="heading-stack"><p class="eyebrow">هنر و آموزش</p><h2>صدا و دانش،<br>در یک مسیر.</h2></div><div class="prose"><h3>موسیقی و خوانندگی</h3><p>موسیقی یکی از حوزه‌های فعالیت من است. صفحهٔ رسمی هنرمند در اسپاتیفای، مسیر دسترسی به آثار منتشرشده است؛ برای محتوای ویدئویی نیز می‌توانید به یوتیوب مراجعه کنید. پیوند هر دو صفحه در بخش موسیقی این وب‌سایت قرار دارد.</p><a class="text-link" href="../music/">مشاهدهٔ صفحهٔ موسیقی {icon('arrow')}</a><h3>تدریس و یادگیری</h3><p>تدریس، بخش دیگری از فعالیت من است. برای گفت‌وگو دربارهٔ آموزش عربی و قرآن، پرسش‌های درسی یا هماهنگی در سبزوار، موضوع را از راه تماس مستقیم یا تلگرام مطرح کنید. در صفحهٔ آموزش، راهنمای کوتاهی برای فرستادن یک پرسش روشن آورده‌ام.</p><a class="text-link" href="../education/">عربی و قرآن {icon('arrow')}</a></div></div></section>
<section class="section"><div class="container content-grid"><div class="heading-stack"><p class="eyebrow">پژوهش و رسانه</p><h2>از پرسیدن<br>تا رساندن پیام.</h2></div><div class="prose"><h3 id="research">پژوهش</h3><p>پژوهش در کنار آموزش، بخشی از معرفی حرفه‌ای من است. برای پیشنهاد موضوع، گفت‌وگوی علمی یا همکاری پژوهشی، توضیحی از مسئله، هدف و نوع همکاری موردنظر را ارسال کنید تا موضوع روشن باشد.</p><h3 id="media">استراتژی و مدیریت رسانه‌های اجتماعی</h3><p>فعالیت من در رسانه به استراتژی محتوا و مدیریت رسانه‌های اجتماعی مربوط می‌شود. برای گفت‌وگو دربارهٔ همکاری، معرفی کوتاهی از صفحه یا پروژه، مخاطبان و هدفی که دنبال می‌کنید بفرستید.</p><p>برای ارتباط، از پیوندهای رسمی این وب‌سایت و شناسهٔ <bdi>@{E(C['handle'])}</bdi> استفاده کنید.</p>{ext('telegram','شروع گفت‌وگو')}</div></div></section>'''

def music():
 return f'''{intro('موسیقی','صدای محمدجواد عرفانی','دسترسی مستقیم به صفحهٔ رسمی هنرمند در اسپاتیفای و کانال یوتیوب؛ برای شنیدن موسیقی و دنبال‌کردن محتوای ویدئویی.')}<section class="section contact-section"><div class="container music-grid">{artwork('music/')}<div class="music-copy"><p class="eyebrow">صفحهٔ رسمی هنرمند</p><h2>موسیقی را دنبال کنید.</h2><p>آثار منتشرشده را در صفحهٔ <bdi>Mohammad Javad Erfani</bdi> در اسپاتیفای بشنوید. با دنبال‌کردن صفحهٔ هنرمند می‌توانید انتشارهای آن را در اسپاتیفای پیگیری کنید.</p><div class="actions">{ext('spotify','شنیدن در اسپاتیفای','button button-primary')}{ext('youtube','دیدن در یوتیوب')}</div>{embed()}</div></div></section><section class="section paper"><div class="container content-grid"><div class="heading-stack"><p class="eyebrow">فراتر از یک پلتفرم</p><h2>بشنوید.<br>ببینید. همراه شوید.</h2></div><div class="prose"><h3>ویدئوها در یوتیوب</h3><p>کانال رسمی با شناسهٔ <bdi>@{E(C['handle'])}</bdi> در دسترس است. برای مشاهدهٔ فهرست ویدئوها و محتوای جدید، از پیوند مستقیم کانال استفاده کنید.</p>{ext('youtube','کانال رسمی یوتیوب','text-link','external')}<h3>ارتباط برای همکاری هنری</h3><p>برای گفت‌وگو دربارهٔ یک پروژهٔ هنری، اجرا یا همکاری، معرفی کوتاه پروژه، زمان مدنظر و راه تماس خود را بفرستید. شمارهٔ تماس و تلگرام رسمی در صفحهٔ ارتباط قرار دارند.</p><a class="text-link" href="../contact/">هماهنگی و ارتباط {icon('arrow')}</a></div></div></section>'''

def education():
 return f'''{intro('عربی و قرآن','عربی، قرآن و مسیر یادگیری','بخش آموزش وب‌سایت محمدجواد عرفانی؛ برای پرسش دربارهٔ عربی و قرآن و هماهنگی ارتباط آموزشی در سبزوار یا از راه دور.')}<section class="section paper"><div class="container education-topics"><article class="topic"><span class="section-number">01 / ARABIC</span><h2>گفت‌وگو دربارهٔ عربی</h2><p>اگر پرسش شما دربارهٔ یک متن، ترجمه یا قواعد عربی است، صورت کامل سؤال و بخش نامفهوم آن را بفرستید. اشاره به پایهٔ تحصیلی یا سطح آشنایی با عربی کمک می‌کند زمینهٔ پرسش روشن‌تر باشد.</p><ul><li>واژگان و ترجمه</li><li>قواعد و ساختار جمله</li><li>درک متن</li></ul></article><article class="topic"><span class="section-number">02 / QURAN</span><h2>پرسش دربارهٔ قرآن</h2><p>برای طرح پرسش آموزشی دربارهٔ قرآن، نام سوره و شمارهٔ آیه یا نام درس و صفحهٔ کتاب را مشخص کنید. اگر دربارهٔ خواندن یا معنای واژه‌ای سؤال دارید، همان بخش را دقیق بنویسید.</p><ul><li>خواندن متن</li><li>معنای واژگان</li><li>پرسش‌های درسی</li></ul></article></div></section><section class="section"><div class="container content-grid"><div class="heading-stack"><p class="eyebrow">برای شروع ارتباط</p><h2>پرسش روشن،<br>گفت‌وگوی بهتر.</h2></div><div class="prose"><p>برای ارتباط با محمدجواد عرفانی دربارهٔ عربی و قرآن، پرسش‌ها را از طریق تلگرام بفرستید. می‌توانید از این ترتیب ساده برای تنظیم پیام استفاده کنید:</p><ol class="steps"><li>موضوع و مقطع تحصیلی یا سطح آشنایی خود را بنویسید.</li><li>متن کامل سؤال، نام منبع و بخش مبهم را مشخص کنید.</li><li>توضیح دهید تا اینجا چه چیزی را فهمیده‌اید و کجا به راهنمایی نیاز دارید.</li><li>اگر هدف هماهنگی است، شهر، زمان پیشنهادی و روش ارتباط را اضافه کنید.</li></ol><div class="actions">{ext('telegram','ارسال پیام در تلگرام','button button-primary')}<a class="button button-outline" href="tel:{E(C['internationalPhone'])}">{icon('phone')}تماس مستقیم</a></div></div></div></section><section class="section connections"><div class="container content-grid"><div class="heading-stack"><p class="eyebrow">هماهنگی در سبزوار</p><h2>راه‌های ارتباط<br>با عرفانی.</h2></div><div><p class="note">برای هماهنگی ارتباط آموزشی در سبزوار، ابتدا از طریق تماس یا تلگرام موضوع را مطرح کنید. زمان، محل یا امکان برگزاری هر جلسه، پس از هماهنگی مشخص می‌شود.</p><div style="margin-top:30px">{faq([('آیا زمان یا ثبت‌نام یک دوره در این صفحه اعلام شده است؟','این صفحه برای معرفی مسیر ارتباط آموزشی است. برای اطلاع از امکان هماهنگی، زمان و جزئیات هر برنامه، مستقیم تماس بگیرید.'),('برای ارتباط غیرحضوری چه کنم؟','در پیام تلگرام بنویسید که ارتباط غیرحضوری مدنظرتان است و موضوع، سطح آموزشی و زمان پیشنهادی را مشخص کنید.')])}</div></div></div></section>'''

def contact():
 return f'''{intro('ارتباط','در تماس باشیم.','برای همکاری هنری، موضوع‌های آموزشی، پژوهش و رسانه؛ از یک پیام کوتاه و روشن شروع کنیم.')}<section class="section contact-section"><div class="container contact-layout"><div><p class="eyebrow">شمارهٔ تماس مستقیم</p><a class="phone-display" href="tel:{E(C['internationalPhone'])}" aria-label="تماس با محمدجواد عرفانی، {E(C['phone'])}">{E(C['phone'])}</a><div class="contact-options"><button hidden class="copy-button" data-copy-phone="{E(C['phone'])}" aria-describedby="copy-status">{icon('copy')} کپی شماره</button><a class="text-link" href="../assets/mohammad-javad-erfani.vcf" download>{icon('download')}ذخیرهٔ مخاطب</a></div><p class="copy-status" id="copy-status" role="status" aria-live="polite"></p><p class="note">برای هماهنگی در سبزوار یا ارتباط از راه دور، موضوع و شیوهٔ ارتباط موردنظرتان را مشخص کنید.</p></div><div class="contact-panel"><h2>گفت‌وگو در تلگرام</h2><p>برای شروع، نام و موضوع پیام را بنویسید؛ همکاری هنری، عربی و قرآن، پژوهش یا مدیریت رسانه. اگر زمان مشخصی مدنظرتان است، آن را هم اضافه کنید.</p>{ext('telegram','پیام به @'+E(C['handle']),'button button-primary')}<p class="privacy-note">پیام شما در تلگرام ارسال می‌شود؛ این سایت فرم جمع‌آوری اطلاعات ندارد.</p></div></div></section><section class="section connections"><div class="container"><div class="section-heading"><div class="heading-stack"><p class="eyebrow">صفحات رسمی</p><h2>همهٔ مسیرهای ارتباط.</h2></div><p>تلگرام، یوتیوب و اینستاگرام با شناسهٔ <bdi>@{E(C['handle'])}</bdi>؛ در کنار اسپاتیفای و نمایهٔ دانش گوگل.</p></div>{social_grid()}</div></section>'''

PAGES=[
('','محمدجواد عرفانی | وب‌سایت رسمی، موسیقی و آموزش','وب‌سایت رسمی محمدجواد عرفانی؛ خواننده، دبیر، پژوهشگر و فعال رسانه. آثار موسیقی، عربی و قرآن، هماهنگی در سبزوار و پیوند شبکه‌های اجتماعی.','ProfilePage',home),
('about/','دربارهٔ محمدجواد عرفانی اصل | موسیقی، آموزش و رسانه','معرفی محمدجواد عرفانی و حوزه‌های فعالیت او در خوانندگی، تدریس، پژوهش و مدیریت رسانه‌های اجتماعی؛ همراه با پیوند صفحات رسمی و راه‌های ارتباط.','AboutPage',about),
('music/','موسیقی محمدجواد عرفانی | اسپاتیفای و یوتیوب رسمی','شنیدن آثار محمدجواد عرفانی در اسپاتیفای و دنبال‌کردن ویدئوها در کانال رسمی یوتیوب Mjerfani؛ همراه با راه ارتباط برای همکاری هنری.','CollectionPage',music),
('education/','عربی و قرآن | محمدجواد عرفانی، ارتباط در سبزوار','مسیر ارتباط آموزشی با محمدجواد عرفانی دربارهٔ عربی و قرآن؛ راهنمای ارسال پرسش درسی و هماهنگی در سبزوار یا از راه دور از طریق تماس و تلگرام.','WebPage',education),
('contact/','تماس با محمدجواد عرفانی | شماره و شبکه‌های اجتماعی','تماس با محمدجواد عرفانی از طریق 09151707322 و تلگرام Mjerfani؛ لینک اینستاگرام، یوتیوب، اسپاتیفای و نمایهٔ دانش گوگل.','ContactPage',contact)]
def schema(path,title,desc,typ):
 url=f'{BASE}/{path}'
 graph=[{'@type':'Person','@id':BASE+'/#person','name':C['name'],'alternateName':[C['latinName'],*C['alternateNames']],'url':BASE+'/','image':BASE+'/assets/images/mohammad-javad-erfani-1280.webp','description':'خواننده، دبیر، پژوهشگر و استراتژیست رسانه‌های اجتماعی','jobTitle':['خواننده','دبیر','پژوهشگر','استراتژیست رسانه‌های اجتماعی'],'telephone':C['internationalPhone'],'sameAs':list(S.values())},
 {'@type':'WebSite','@id':BASE+'/#website','url':BASE+'/','name':C['name'],'alternateName':['Mjerfani',C['latinName']],'inLanguage':'fa-IR','publisher':{'@id':BASE+'/#person'}},
 {'@type':typ,'@id':url+'#webpage','url':url,'name':title,'description':desc,'inLanguage':'fa-IR','isPartOf':{'@id':BASE+'/#website'},'mainEntity':{'@id':BASE+'/#person'},'primaryImageOfPage':{'@type':'ImageObject','url':BASE+'/assets/images/mohammad-javad-erfani-1280.webp','width':1280,'height':1280}}]
 if path:
  label=next(l for p,l in NAV if p==path)
  graph.append({'@type':'BreadcrumbList','@id':url+'#breadcrumb','itemListElement':[{'@type':'ListItem','position':1,'name':'خانه','item':BASE+'/'},{'@type':'ListItem','position':2,'name':label,'item':url}]})
  graph[2]['breadcrumb']={'@id':url+'#breadcrumb'}
 return json.dumps({'@context':'https://schema.org','@graph':graph},ensure_ascii=False,indent=2).replace('<','\\u003c')
def write_page(path,title,desc,typ,render):
 prefix='../' if path else './';url=f'{BASE}/{path}'
 verify=f'<meta name="google-site-verification" content="{E(C["googleSiteVerification"])}">' if C['googleSiteVerification'] else ''
 html=f'''<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(title)}</title><meta name="description" content="{E(desc)}"><meta name="author" content="{E(C['name'])}">
<meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"><meta name="theme-color" content="#111113"><meta name="color-scheme" content="dark light"><meta name="format-detection" content="telephone=no">
<link rel="canonical" href="{E(url)}"><link rel="alternate" hreflang="fa-IR" href="{E(url)}">
<meta property="og:type" content="{'profile' if path in ('','about/') else 'website'}"><meta property="og:locale" content="fa_IR"><meta property="og:site_name" content="{E(C['name'])}"><meta property="og:title" content="{E(title)}"><meta property="og:description" content="{E(desc)}"><meta property="og:url" content="{E(url)}">
<meta property="og:image" content="{E(BASE)}/assets/images/social-preview.jpg"><meta property="og:image:type" content="image/jpeg"><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:image:alt" content="پرترهٔ محمدجواد عرفانی">
<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="{E(title)}"><meta name="twitter:description" content="{E(desc)}"><meta name="twitter:image" content="{E(BASE)}/assets/images/social-preview.jpg"><meta name="twitter:image:alt" content="پرترهٔ محمدجواد عرفانی">
{verify}<link rel="icon" type="image/svg+xml" href="{prefix}assets/images/favicon.svg"><link rel="icon" type="image/png" sizes="32x32" href="{prefix}assets/images/favicon-32.png"><link rel="apple-touch-icon" sizes="180x180" href="{prefix}assets/images/apple-touch-icon.png"><link rel="preload" href="{prefix}assets/fonts/Vazirmatn.woff2" as="font" type="font/woff2" crossorigin><link rel="stylesheet" href="{prefix}assets/css/style.css?v=1"><script src="{prefix}assets/js/main.js?v=1" defer></script><script type="application/ld+json">{schema(path,title,desc,typ)}</script>
</head><body class="page-{path.strip('/') or 'home'}">{header(path)}<main id="main">{render()}</main>{band()}{footer(path)}</body></html>'''
 dest=ROOT/path/'index.html';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(html,encoding='utf-8')
for page in PAGES:write_page(*page)
(ROOT/'robots.txt').write_text(f'User-agent: *\nAllow: /\n\nSitemap: {BASE}/sitemap.xml\n',encoding='utf-8')
(ROOT/'CNAME').write_text(urlparse(BASE).hostname+'\n',encoding='ascii')
entries=[]
for path,*_ in PAGES:
 entry=f'<url><loc>{E(BASE)}/{path}</loc><lastmod>{E(C["updated"])}</lastmod>'
 for image_name in (['mohammad-javad-erfani-1280.webp'] if path in ('','about/') else [])+(['erfani-artwork-960.webp'] if path in ('','music/') else []):
  entry+=f'<image:image><image:loc>{E(BASE)}/assets/images/{image_name}</image:loc></image:image>'
 entries.append(entry+'</url>')
(ROOT/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n'+'\n'.join(entries)+'\n</urlset>\n',encoding='utf-8')
vcard=['BEGIN:VCARD','VERSION:3.0',f'FN:{C["name"]}','N:عرفانی;محمدجواد;;;',f'TEL;TYPE=CELL:{C["internationalPhone"]}',f'URL:{BASE}/',f'NOTE:Telegram: @{C["handle"]}','END:VCARD','']
(ROOT/'assets/mohammad-javad-erfani.vcf').write_bytes('\r\n'.join(vcard).encode('utf-8'))
(ROOT/'404.html').write_text(f'''<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,follow"><title>صفحه پیدا نشد | محمدجواد عرفانی</title><style>body{{margin:0;min-height:100vh;display:grid;place-items:center;background:#111113;color:#f0ece4;font:17px/2 Tahoma,sans-serif}}main{{padding:30px;max-width:600px}}b{{font:100px Arial;color:#e74444}}h1{{font-size:29px}}p{{color:#b5b2ad}}a{{display:inline-block;padding:10px 23px;background:#b72a30;color:#fff;text-decoration:none;margin-top:20px}}a:focus-visible{{outline:3px solid white;outline-offset:5px}}</style><main><b>404</b><h1>این صفحه پیدا نشد.</h1><p>ممکن است نشانی تغییر کرده باشد. از صفحهٔ اصلی، مسیر موردنظرتان را پیدا کنید.</p><a href="{E(BASE)}/">بازگشت به صفحهٔ اصلی</a></main></html>''',encoding='utf-8')
print('Built 5 pages, 404, sitemap, robots, CNAME and contact card.')
