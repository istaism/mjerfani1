#!/usr/bin/env python3
"""Check the real generated pages, links, fragments, metadata, schema and assets."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlparse,unquote
import json,re,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
C=json.loads((ROOT/'site.json').read_text(encoding='utf-8'));BASE=C['url'].rstrip('/')
FILES=[ROOT/n for n in ['index.html','about/index.html','music/index.html','education/index.html','contact/index.html','404.html']]
errors=[];canonicals=[];titles=[]
class Page(HTMLParser):
 def __init__(self,text):
  super().__init__();self.tags=[];self.ids=[];self.h1=0;self.title='';self.in_title=False;self.feed(text)
 def handle_starttag(self,tag,attrs):
  a=dict(attrs);self.tags.append((tag,a))
  if a.get('id'):self.ids.append(a['id'])
  if tag=='h1':self.h1+=1
  if tag=='title':self.in_title=True
 def handle_endtag(self,tag):
  if tag=='title':self.in_title=False
 def handle_data(self,data):
  if self.in_title:self.title+=data
PARSERS={f:Page(f.read_text(encoding='utf-8')) for f in FILES}
def check(ok,msg):
 if not ok:errors.append(msg)
def resource(source,ref):
 u=urlparse(ref)
 if u.scheme or u.netloc:return
 p=(ROOT/unquote(u.path).lstrip('/') if u.path.startswith('/') else source.parent/unquote(u.path)).resolve() if u.path else source
 if p.is_dir():p=p/'index.html'
 check(p.is_file(),f'{source.relative_to(ROOT)}: missing {ref}')
 if u.fragment and p in PARSERS:check(unquote(u.fragment) in PARSERS[p].ids,f'{source.name}: missing fragment {ref}')
for f,p in PARSERS.items():
 source=f.read_text(encoding='utf-8');name=str(f.relative_to(ROOT))
 check(p.h1==1,f'{name}: expected one H1');check(len(p.ids)==len(set(p.ids)),f'{name}: duplicate IDs')
 check(bool(p.title.strip()),f'{name}: missing title');titles.append(p.title)
 check('09999035098' not in source and '989999035098' not in source and 'g.co/kgs/bxU5xS' not in source,f'{name}: old contact')
 check('lang="fa"' in source and 'dir="rtl"' in source,f'{name}: language/direction')
 for tag,a in p.tags:
  if tag in ['a','link'] and a.get('href'):resource(f,a['href'])
  if tag in ['img','script','iframe'] and a.get('src'):resource(f,a['src'])
  if tag=='img':
   check(bool(a.get('alt')),f'{name}: missing image alt');check(a.get('width') and a.get('height'),f'{name}: missing image dimensions')
   for item in a.get('srcset','').split(','):
    if item.strip():resource(f,item.strip().split()[0])
  if tag=='a' and a.get('target')=='_blank':check('noopener' in a.get('rel',''),f'{name}: unsafe external tab')
 if f.name=='404.html':check('noindex' in source,'404 should be noindex');continue
 meta={a.get('name') or a.get('property'):a.get('content','') for tag,a in p.tags if tag=='meta'}
 check(60<=len(meta.get('description',''))<=190,f'{name}: description length')
 check('index' in meta.get('robots','') and 'noindex' not in meta.get('robots',''),f'{name}: indexing directive')
 can=[a['href'] for tag,a in p.tags if tag=='link' and a.get('rel')=='canonical']
 expected=BASE+'/'+('' if f.parent==ROOT else f.parent.name+'/')
 check(can==[expected],f'{name}: canonical');canonicals.extend(can)
 check(meta.get('og:url')==expected,f'{name}: OG URL')
 for k in ['og:image','twitter:image']:
  u=urlparse(meta.get(k,''));check(u.scheme=='https' and (ROOT/u.path.lstrip('/')).is_file(),f'{name}: share image')
 data=re.findall(r'<script type="application/ld\+json">(.*?)</script>',source,re.S)
 check(len(data)==1,f'{name}: schema count')
 if data:
  graph=json.loads(data[0])['@graph'];person=next(x for x in graph if x['@type']=='Person')
  check(person['telephone']==C['internationalPhone'],f'{name}: schema phone')
  check(set(person['sameAs'])==set(C['social'].values()),f'{name}: schema links')
 check(C['internationalPhone'] in source,f'{name}: missing telephone')
check(len(titles)==len(set(titles)),'Duplicate titles')
sm=ET.parse(ROOT/'sitemap.xml');locs=[x.text for x in sm.findall('.//{http://www.sitemaps.org/schemas/sitemap/0.9}loc')]
check(set(locs)==set(canonicals) and len(locs)==len(canonicals),'Sitemap/canonical mismatch')
check((ROOT/'CNAME').read_text().strip()==urlparse(BASE).hostname,'CNAME mismatch')
check(f'Sitemap: {BASE}/sitemap.xml' in (ROOT/'robots.txt').read_text(),'robots sitemap mismatch')
css=(ROOT/'assets/css/style.css').read_text()
for p in re.findall(r'url\([\'"]?([^\'"\)]+)',css):resource(ROOT/'assets/css/style.css',p)
check((ROOT/'assets/fonts/Vazirmatn.woff2').read_bytes()[:4]==b'wOF2','Font format')
check((ROOT/'assets/fonts/OFL.txt').is_file(),'Font license')
check(C['internationalPhone'].encode() in (ROOT/'assets/mohammad-javad-erfani.vcf').read_bytes(),'vCard phone')
for u in C['social'].values():check(u in (ROOT/'contact/index.html').read_text(),f'Missing social link {u}')
if errors:
 print('\n'.join('FAIL: '+x for x in errors));raise SystemExit(1)
print('PASS: 6 HTML pages; 5 unique indexable canonicals; sitemap; JSON-LD; local assets, links and fragments; social links; phone; vCard; font license.')
