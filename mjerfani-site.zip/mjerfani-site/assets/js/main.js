(() => {
  'use strict';
  document.documentElement.classList.add('js');
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.getElementById('primary-nav');
  const mobile = window.matchMedia('(max-width: 850px)');
  const setMenu = (open, restoreFocus = false) => {
    if (!toggle || !nav) return;
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'بستن فهرست' : 'باز کردن فهرست');
    nav.classList.toggle('is-open', open);
    document.body.classList.toggle('menu-open', open);
    if (open) nav.querySelector('a')?.focus();
    else if (restoreFocus) toggle.focus();
  };
  toggle?.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  nav?.addEventListener('click', event => { if (event.target.closest('a')) setMenu(false); });
  document.addEventListener('keydown', event => {
    if (!nav?.classList.contains('is-open')) return;
    if (event.key === 'Escape') { event.preventDefault(); setMenu(false, true); }
    if (event.key === 'Tab') {
      const focusable = [toggle, ...nav.querySelectorAll('a')];
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  mobile.addEventListener('change', () => setMenu(false));
  document.querySelectorAll('[data-copy-phone]').forEach(button => {
    button.hidden = false;
    button.addEventListener('click', async () => {
      const phone = button.dataset.copyPhone;
      const status = document.getElementById(button.getAttribute('aria-describedby'));
      try {
        if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
        await navigator.clipboard.writeText(phone);
        if (status) status.textContent = 'شمارهٔ تماس کپی شد.';
      } catch {
        const field = document.createElement('textarea');
        field.value = phone; field.readOnly = true;
        field.style.cssText = 'position:fixed;left:-9999px;top:0;';
        const focused = document.activeElement;
        document.body.append(field); field.select(); field.setSelectionRange(0, phone.length);
        let copied = false;
        try { copied = document.execCommand('copy'); } catch { /* manual fallback */ }
        field.remove(); focused?.focus();
        if (status) status.textContent = copied ? 'شمارهٔ تماس کپی شد.' : `کپی خودکار ممکن نشد. شماره را انتخاب و کپی کنید: ${phone}`;
      }
    });
  });
  document.querySelectorAll('[data-spotify-load]').forEach(button => {
    button.hidden = false;
    button.addEventListener('click', () => {
      const box = button.closest('.embed-shell'), id = button.dataset.spotifyLoad;
      if (!box || box.dataset.loaded === 'true' || !/^[A-Za-z0-9]{22}$/.test(id)) return;
      const frame = document.createElement('iframe');
      frame.title = 'پخش‌کنندهٔ اسپاتیفای محمدجواد عرفانی';
      frame.src = `https://open.spotify.com/embed/artist/${id}?utm_source=generator&theme=0`;
      frame.width = '100%'; frame.height = '352';
      frame.allow = 'autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture';
      frame.referrerPolicy = 'strict-origin-when-cross-origin'; frame.allowFullscreen = true;
      box.dataset.loaded = 'true'; box.replaceChildren(frame); frame.focus();
    });
  });
})();
